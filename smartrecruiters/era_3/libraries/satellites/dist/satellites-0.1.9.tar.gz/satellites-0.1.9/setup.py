# -*- coding: utf-8 -*-
from distutils.core import setup

packages = \
['satellites']

package_data = \
{'': ['*']}

install_requires = \
['django>=2.2,<3.0', 'requests>=2.21,<3.0']

setup_kwargs = {
    'name': 'satellites',
    'version': '0.1.9',
    'description': 'A client library for the Smartian Satellites.',
    'long_description': None,
    'author': 'Elliott Maguire',
    'author_email': 'e.maguire@smartrecruiters.com',
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
