"""
satellites.e
~~~~~~~~~~~~

This module implements the client for satellite-e (enrichment).
"""

import requests


class Enrichment:
    def __init__(self, token):
        self.base = 'https://enrichment.smartian.space'
        self.token = token

    def get_accounts(self, params=None):
        """ Gets a list of active accounts. """
        url = ''.join([self.base, f"/accounts"])
        headers = {'x-token': self.token}

        response = requests.get(
            url, headers=headers, params=params)

        return response

    def get_account(self, sfid):
        """ Gets an account by Salesforce ID. """
        url = ''.join([self.base, f"/accounts/{sfid}"])
        headers = {'x-token': self.token}

        response = requests.get(url, headers=headers)

        return response

    def update_account(self, sfid, data):
        """ Updates an account by Salesforce ID. """
        url = ''.join([self.base, f"/accounts/{sfid}/update"])
        headers = {'x-token': self.token}

        response = requests.post(url, headers=headers, data=data)

        return response

    def remove_account(self, sfid):
        """ Removes an account from the temporary database. """
        url = ''.join([self.base, f"/accounts/{sfid}/remove"])
        headers = {'x-token': self.token}

        response = requests.delete(url, headers=headers)

        return response

    def create_contact(self, sfid, data):
        """ Creates a new contact. """
        url = ''.join([self.base, f"/contacts/{sfid}/create"])
        headers = {'x-token': self.token}

        response = requests.post(url, headers=headers, data=data)

        return response

    def get_contacts(self, sfid, params):
        """ Gets a list of contacts based on parameters. """
        url = ''.join([self.base, f"/contacts/{sfid}"])
        headers = {'x-token': self.token}

        response = requests.get(url, headers=headers, params=params)

        return response

    def update_contact(self, sfid, cid, data):
        """ Updates a contact by Salesforce ID. """
        url = ''.join([self.base, f"/contacts/{sfid}/{cid}/update"])
        headers = {'x-token': self.token}

        response = requests.post(url, headers=headers, data=data)

        return response
