"""
satellites.spy
~~~~~~~~~~~~~~

This module implements the client for satellite-e (enrichment).
"""

import requests


class Spy:
    def __init__(self, token):
        self.base = 'https://spy.satellites.smartian.space'
        self.token = token

    """
satellites.e
~~~~~~~~~~~~

This module implements the client for satellite-e (enrichment).
"""

import requests


class Enrichment:
    def __init__(self, token):
        self.base = 'https://e.satellites.smartian.space'
        self.token = token

    def get_competitors(self, params=None):
        """ Gets a list of competitors. """
        url = ''.join([self.base, f"/competitors"])
        headers = {'Authorization': f"Basic {self.token}"}

        response = requests.get(
            url, headers=headers, params=params)

        return response

    def update_competitor(self, id, data):
        """ Updates a competitor by ID. """
        url = ''.join([self.base, f"/competitors/{id}/update"])
        headers = {'Authorization': f"Basic {self.token}"}

        response = requests.post(url, headers=headers, data=data)

        return response

    def create_resource(self, data):
        """ Creates a new resource. """
        url = ''.join([self.base, f"/resources/create"])
        headers = {'Authorization': f"Basic {self.token}"}

        response = requests.post(url, headers=headers, data=data)

        return response

    def get_resources(self, params):
        """ Gets a list of resources based on parameters. """
        url = ''.join([self.base, f"/resources"])
        headers = {'Authorization': f"Basic {self.token}"}

        response = requests.get(url, headers=headers, params=params)

        return response

    def update_resource(self, id, data):
        """ Updates a resource by ID. """
        url = ''.join([self.base, f"/resources/{id}/update"])
        headers = {'Authorization': f"Basic {self.token}"}

        response = requests.post(url, headers=headers, data=data)

        return response

    def create_insight(self, data):
        """ Creates a new insight. """
        url = ''.join([self.base, f"/insights/create"])
        headers = {'Authorization': f"Basic {self.token}"}

        response = requests.post(url, headers=headers, data=data)

        return response

    def get_insights(self, params):
        """ Gets a list of insights based on parameters. """
        url = ''.join([self.base, f"/insights"])
        headers = {'Authorization': f"Basic {self.token}"}

        response = requests.get(url, headers=headers, params=params)

        return response

    def update_insight(self, id, data):
        """ Updates a insight by ID. """
        url = ''.join([self.base, f"/insights/{id}/update"])
        headers = {'Authorization': f"Basic {self.token}"}

        response = requests.post(url, headers=headers, data=data)

        return response

    def create_comment(self, cid, data):
        """ Creates a new comment. """
        url = ''.join([self.base, f"/comments/create"])
        headers = {'Authorization': f"Basic {self.token}"}

        response = requests.post(url, headers=headers, data=data)

        return response

    def get_comments(self, params):
        """ Gets a list of comments based on parameters. """
        url = ''.join([self.base, f"/comments"])
        headers = {'Authorization': f"Basic {self.token}"}

        response = requests.get(url, headers=headers, params=params)

        return response

    def update_comment(self, id, data):
        """ Updates a comment by ID. """
        url = ''.join([self.base, f"/comments/{id}/update"])
        headers = {'Authorization': f"Basic {self.token}"}

        response = requests.post(url, headers=headers, data=data)

        return response